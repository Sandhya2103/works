$(document).ready(function() {
    $('body').bootstrapMaterialDesign();
});